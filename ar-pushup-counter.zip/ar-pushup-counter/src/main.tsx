import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { PoseLandmarker } from '@mediapipe/tasks-vision';
import { createPoseLandmarker, drawAROverlay } from './pose';
import { PushupCounter } from './pushupCounter';
import type { PushupMetrics } from './types';
import './styles.css';

function App() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const poseRef = useRef<PoseLandmarker | null>(null);
  const rafRef = useRef<number | null>(null);
  const counter = useMemo(() => new PushupCounter(), []);

  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [deviceId, setDeviceId] = useState('');
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [isRunning, setIsRunning] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [metrics, setMetrics] = useState<PushupMetrics>({
    count: 0,
    state: 'ready',
    elbowAngle: null,
    bodyLineAngle: null,
    feedback: 'กดเริ่มเพื่อเปิดกล้อง',
    quality: 'warn'
  });

  async function refreshDevices() {
    const list = await navigator.mediaDevices.enumerateDevices();
    setDevices(list.filter((d) => d.kind === 'videoinput'));
  }

  async function stopCamera() {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setIsRunning(false);
  }

  async function startCamera(nextDeviceId = deviceId, facing = cameraFacing) {
    setError('');
    setIsLoading(true);
    try {
      await stopCamera();

      const constraints: MediaStreamConstraints = {
        video: nextDeviceId
          ? { deviceId: { exact: nextDeviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }
          : { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (!videoRef.current) return;
      videoRef.current.srcObject = stream;
      await videoRef.current.play();

      if (!poseRef.current) poseRef.current = await createPoseLandmarker();
      await refreshDevices();
      setIsRunning(true);
      renderLoop();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'เปิดกล้องไม่ได้';
      setError(message);
      setMetrics((m) => ({ ...m, feedback: 'เปิดกล้องไม่ได้ ตรวจสอบสิทธิ์กล้อง/HTTPS' }));
    } finally {
      setIsLoading(false);
    }
  }

  function renderLoop() {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const pose = poseRef.current;

    if (video && canvas && pose && video.readyState >= 2) {
      const result = pose.detectForVideo(video, performance.now());
      const landmarks = result.landmarks?.[0];
      drawAROverlay(canvas, video, landmarks);
      setMetrics(counter.update(landmarks));
    }

    rafRef.current = requestAnimationFrame(renderLoop);
  }

  function resetCount() {
    counter.reset();
    setMetrics({
      count: 0,
      state: 'ready',
      elbowAngle: null,
      bodyLineAngle: null,
      feedback: 'รีเซ็ตแล้ว เริ่มวิดพื้นได้เลย',
      quality: 'good'
    });
  }

  async function switchFacing() {
    const next = cameraFacing === 'environment' ? 'user' : 'environment';
    setCameraFacing(next);
    setDeviceId('');
    await startCamera('', next);
  }

  useEffect(() => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setError('เบราว์เซอร์นี้ไม่รองรับกล้องผ่าน getUserMedia');
      return;
    }
    refreshDevices().catch(() => undefined);
    return () => {
      stopCamera();
      poseRef.current?.close();
    };
  }, []);

  return (
    <main className="app">
      <section className="hero">
        <div>
          <p className="eyebrow">AR Camera Fitness</p>
          <h1>นับวิดพื้นด้วยกล้อง</h1>
          <p className="subtitle">เลือกกล้องได้ทุกตัว วาดโครงกระดูก AR และนับเมื่อคุณลง-ขึ้นครบจังหวะ</p>
        </div>
        <div className={`counter ${metrics.quality}`}>
          <span>{metrics.count}</span>
          <small>ครั้ง</small>
        </div>
      </section>

      <section className="cameraCard">
        <div className="stage">
          <video ref={videoRef} playsInline muted className="video" />
          <canvas ref={canvasRef} className="overlay" />
          {!isRunning && <div className="placeholder">กด “เริ่มกล้อง” แล้ววางมือถือด้านข้างลำตัว</div>}
        </div>

        <div className="controls">
          <button onClick={() => startCamera()} disabled={isLoading}>
            {isLoading ? 'กำลังโหลด...' : isRunning ? 'รีสตาร์ทกล้อง' : 'เริ่มกล้อง'}
          </button>
          <button onClick={switchFacing} disabled={isLoading}>สลับหน้า/หลัง</button>
          <button onClick={resetCount}>รีเซ็ต</button>
          <button onClick={stopCamera}>หยุด</button>
        </div>

        <label className="selectLabel">
          เลือกกล้อง
          <select
            value={deviceId}
            onChange={(e) => {
              const id = e.target.value;
              setDeviceId(id);
              startCamera(id).catch(() => undefined);
            }}
          >
            <option value="">อัตโนมัติ ({cameraFacing === 'environment' ? 'กล้องหลัง' : 'กล้องหน้า'})</option>
            {devices.map((device, index) => (
              <option key={device.deviceId} value={device.deviceId}>
                {device.label || `Camera ${index + 1}`}
              </option>
            ))}
          </select>
        </label>

        {error && <p className="error">{error}</p>}
      </section>

      <section className="statusGrid">
        <Status label="สถานะ" value={metrics.state} />
        <Status label="มุมศอก" value={metrics.elbowAngle ? `${Math.round(metrics.elbowAngle)}°` : '-'} />
        <Status label="ลำตัวเบี้ยว" value={metrics.bodyLineAngle ? `${Math.round(metrics.bodyLineAngle)}°` : '-'} />
        <Status label="คำแนะนำ" value={metrics.feedback} wide />
      </section>

      <section className="tips">
        <h2>วิธีใช้ให้แม่น</h2>
        <p>ตั้งกล้องด้านข้าง เห็นทั้งมือ ศอก ไหล่ สะโพก และข้อเท้า ไฟควรสว่าง และอย่าให้คนอื่นเข้ากล้อง</p>
      </section>
    </main>
  );
}

function Status({ label, value, wide = false }: { label: string; value: string; wide?: boolean }) {
  return (
    <div className={wide ? 'status wide' : 'status'}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

createRoot(document.getElementById('root')!).render(<App />);
