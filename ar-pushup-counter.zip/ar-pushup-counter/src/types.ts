export type Landmark = {
  x: number;
  y: number;
  z?: number;
  visibility?: number;
};

export type PushupState = 'ready' | 'up' | 'down';

export type PushupMetrics = {
  count: number;
  state: PushupState;
  elbowAngle: number | null;
  bodyLineAngle: number | null;
  feedback: string;
  quality: 'good' | 'warn' | 'bad';
};
