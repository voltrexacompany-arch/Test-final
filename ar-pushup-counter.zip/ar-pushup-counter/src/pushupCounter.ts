import type { Landmark, PushupMetrics, PushupState } from './types';

const NOSE = 0;
const LEFT_SHOULDER = 11;
const RIGHT_SHOULDER = 12;
const LEFT_ELBOW = 13;
const RIGHT_ELBOW = 14;
const LEFT_WRIST = 15;
const RIGHT_WRIST = 16;
const LEFT_HIP = 23;
const RIGHT_HIP = 24;
const LEFT_ANKLE = 27;
const RIGHT_ANKLE = 28;

type Side = 'left' | 'right';

function avg(a: Landmark, b: Landmark): Landmark {
  return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: ((a.z ?? 0) + (b.z ?? 0)) / 2 };
}

function visible(point?: Landmark, min = 0.45): point is Landmark {
  return !!point && (point.visibility ?? 1) >= min;
}

function angle(a: Landmark, b: Landmark, c: Landmark): number {
  const ab = { x: a.x - b.x, y: a.y - b.y };
  const cb = { x: c.x - b.x, y: c.y - b.y };
  const dot = ab.x * cb.x + ab.y * cb.y;
  const magAB = Math.hypot(ab.x, ab.y);
  const magCB = Math.hypot(cb.x, cb.y);
  const cos = dot / Math.max(magAB * magCB, 0.000001);
  return Math.acos(Math.min(1, Math.max(-1, cos))) * (180 / Math.PI);
}

function pickSide(lm: Landmark[]): Side | null {
  const left = [lm[LEFT_SHOULDER], lm[LEFT_ELBOW], lm[LEFT_WRIST], lm[LEFT_HIP], lm[LEFT_ANKLE]];
  const right = [lm[RIGHT_SHOULDER], lm[RIGHT_ELBOW], lm[RIGHT_WRIST], lm[RIGHT_HIP], lm[RIGHT_ANKLE]];
  const leftScore = left.reduce((sum, p) => sum + (p?.visibility ?? 0), 0);
  const rightScore = right.reduce((sum, p) => sum + (p?.visibility ?? 0), 0);
  if (Math.max(leftScore, rightScore) < 2.2) return null;
  return leftScore >= rightScore ? 'left' : 'right';
}

function getSidePoints(lm: Landmark[], side: Side) {
  if (side === 'left') {
    return {
      shoulder: lm[LEFT_SHOULDER],
      elbow: lm[LEFT_ELBOW],
      wrist: lm[LEFT_WRIST],
      hip: lm[LEFT_HIP],
      ankle: lm[LEFT_ANKLE]
    };
  }
  return {
    shoulder: lm[RIGHT_SHOULDER],
    elbow: lm[RIGHT_ELBOW],
    wrist: lm[RIGHT_WRIST],
    hip: lm[RIGHT_HIP],
    ankle: lm[RIGHT_ANKLE]
  };
}

function lineAngle(a: Landmark, b: Landmark, c: Landmark): number {
  return 180 - angle(a, b, c);
}

export class PushupCounter {
  private count = 0;
  private state: PushupState = 'ready';
  private downArmed = false;
  private lastRepTime = 0;

  reset() {
    this.count = 0;
    this.state = 'ready';
    this.downArmed = false;
    this.lastRepTime = 0;
  }

  update(landmarks?: Landmark[], now = performance.now()): PushupMetrics {
    if (!landmarks || landmarks.length < 29) {
      return this.metrics(null, null, 'เข้ากล้องให้เห็นไหล่ ศอก ข้อมือ สะโพก และข้อเท้า', 'warn');
    }

    const side = pickSide(landmarks);
    if (!side) {
      return this.metrics(null, null, 'หันข้างให้กล้องเห็นทั้งลำตัว จะนับแม่นกว่า', 'warn');
    }

    const p = getSidePoints(landmarks, side);
    const required = [p.shoulder, p.elbow, p.wrist, p.hip, p.ankle];
    if (!required.every((point) => visible(point))) {
      return this.metrics(null, null, 'กล้องยังเห็นข้อต่อไม่ครบ ลองถอยออกอีกนิด', 'warn');
    }

    const elbow = angle(p.shoulder, p.elbow, p.wrist);
    const bodyLine = lineAngle(p.shoulder, p.hip, p.ankle);
    const head = visible(landmarks[NOSE], 0.25) ? landmarks[NOSE] : avg(landmarks[LEFT_SHOULDER], landmarks[RIGHT_SHOULDER]);
    const shoulderHipDist = Math.hypot(p.shoulder.x - p.hip.x, p.shoulder.y - p.hip.y);
    const tooClose = shoulderHipDist > 0.48;

    let feedback = 'พร้อมนับวิดพื้น';
    let quality: PushupMetrics['quality'] = 'good';

    if (tooClose) {
      feedback = 'ตัวใกล้กล้องเกินไป ลองถอยออกเพื่อให้เห็นเต็มตัว';
      quality = 'warn';
    } else if (bodyLine > 28) {
      feedback = 'เกร็งลำตัวให้ตรง อย่าให้สะโพกตกหรือโด่งเกินไป';
      quality = 'bad';
    } else if (head.y < 0.02 || head.y > 0.98) {
      feedback = 'จัดเฟรมให้เห็นหัวและลำตัวครบ';
      quality = 'warn';
    }

    const downThreshold = 95;
    const upThreshold = 155;
    const debounceMs = 450;

    if (elbow < downThreshold) {
      this.state = 'down';
      this.downArmed = true;
      if (quality === 'good') feedback = 'ลงสุดแล้ว ดันขึ้นให้แขนเกือบตรง';
    }

    if (elbow > upThreshold) {
      if (this.downArmed && now - this.lastRepTime > debounceMs) {
        this.count += 1;
        this.lastRepTime = now;
        feedback = `ครบ 1 ครั้ง! รวม ${this.count} ครั้ง`;
      } else if (quality === 'good') {
        feedback = 'ลงต่อจนศอกงอประมาณ 90°';
      }
      this.state = 'up';
      this.downArmed = false;
    }

    return this.metrics(elbow, bodyLine, feedback, quality);
  }

  private metrics(
    elbowAngle: number | null,
    bodyLineAngle: number | null,
    feedback: string,
    quality: PushupMetrics['quality']
  ): PushupMetrics {
    return {
      count: this.count,
      state: this.state,
      elbowAngle,
      bodyLineAngle,
      feedback,
      quality
    };
  }
}
