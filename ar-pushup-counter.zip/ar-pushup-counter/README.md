# AR Push-up Counter

แอพนับวิดพื้นด้วยกล้องผ่านเว็บ/PWA ใช้ MediaPipe Pose Landmarker ตรวจจับท่าทางแบบเรียลไทม์ แล้ววาดโครงกระดูกแบบ AR overlay บนวิดีโอ

## ฟีเจอร์

- นับจำนวนวิดพื้นจากมุมศอก: ลงจนศอกงอ แล้วขึ้นจนแขนเกือบตรง
- เลือกกล้องได้ทุกตัวที่ browser มองเห็น เช่น กล้องหน้า กล้องหลัง webcam หรือ external camera
- ปุ่มสลับกล้องหน้า/หลัง
- AR overlay วาดข้อต่อและเส้นโครงกระดูกทับวิดีโอ
- คำแนะนำท่าทาง เช่น ลำตัวไม่ตรงหรือเข้าเฟรมไม่ครบ
- ทำเป็น PWA ติดตั้งลงมือถือได้จาก browser

## เทคโนโลยี

- React + TypeScript + Vite
- MediaPipe Tasks Vision / Pose Landmarker
- MediaDevices API: getUserMedia + enumerateDevices
- vite-plugin-pwa

## วิธีรัน

```bash
npm install
npm run dev
```

เปิด URL ที่ Vite แสดงใน browser แล้วกดอนุญาตใช้กล้อง

> หมายเหตุ: กล้องบนมือถือมักต้องใช้ `https` หรือ `localhost` ถ้าจะทดสอบผ่านมือถือจริงให้ deploy ขึ้น Vercel/Netlify/GitHub Pages หรือใช้ tunnel เช่น ngrok/cloudflared

## วิธีใช้งาน

1. วางมือถือหรือกล้องด้านข้างลำตัว
2. ให้เห็นมือ ศอก ไหล่ สะโพก และข้อเท้าในเฟรม
3. กด “เริ่มกล้อง”
4. เลือกกล้องจาก dropdown ถ้ามีหลายกล้อง
5. เริ่มวิดพื้น แอพจะนับเมื่อคุณลงและดันขึ้นครบหนึ่งรอบ

## ปรับความไวการนับ

แก้ไฟล์ `src/pushupCounter.ts`

- `downThreshold = 95` ยิ่งมาก ยิ่งนับว่าลงง่ายขึ้น
- `upThreshold = 155` ยิ่งน้อย ยิ่งนับว่าขึ้นง่ายขึ้น
- `debounceMs = 450` กันนับซ้ำเร็วเกินไป

## สร้างไฟล์ production

```bash
npm run build
npm run preview
```

## สร้าง repo บน GitHub

ชื่อ repo แนะนำ: `ar-pushup-counter`

```bash
git init
git add .
git commit -m "Initial AR push-up counter app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ar-pushup-counter.git
git push -u origin main
```
